#!/bin/bash

USER=$(whoami)
RUTA=/home/$USER
FICHERO_DESCARGA=$RUTA/descarga
MOTION=$RUTA/motion.conf
DOCUMENTROOT=$RUTA/cam
		
function inicio(){
	clear
	cd $RUTA
	rm $FICHERO_DESCARGA
	rm $MOTION
	clear

	install_motion
	
}
 
function install_motion(){
	echo -e "\e[1;34mInstalando motion.\e[0m"
	sudo apt-get -y install motion
	clear
	echo -e "\e[1;34mmotion instalado con exito.\e[0m"
	clear
	echo -e "\e[1;34mcreando directorio para la configuración de motion.\e[0m"
	mkdir $RUTA/.motion
	clear
	echo -e "\e[1;34mcreando carpetas para de motion.\e[0m"
	mkdir -p $RUTA/cam/
	clear
	echo -e "\e[1;34mañadiendo usuario al grupo motion.\e[0m"
	sudo usermod -a -G motion $USER
	clear
	echo -e "\e[1;34mDescargando el archivo de configuración de motion a nuestra carpeta local.\e[0m"

	wget https://googledrive.com/host/0B0NyOnDe7f7Oa1FSSzR 
	echo "descarga ok" > $FICHERO_DESCARGA 
	if [ -f $FICHERO_DESCARGA ]; then
		echo -e "\e[1;32mdescarga completada.\e[0m"
		echo "target_dir $DOCUMENTROOT" >> $MOTION
		cp $MOTION $RUTA/.motion
	else
		echo -e "\e[1;31mSe produjo un error en la descarga.\e[0m"
		borrar
		exit -1
	fi
	clear
	echo -e "\e[1;34mtomando en posesión el archivo motion.conf.\e[0m"
	sudo chown $USER:motion $MOTION
}

function borrar(){
	echo -e "\e[1;31mSe produjo un error durante el proceso.\e[0m"
	echo "Desinstalando ..." 
	sudo apt-get -y remove --purge motion

	rm $FICHERO_DESCARGA
	rm $MOTION
	killall install_motion.sh
	exit -2
}

function finishcheck(){
	rm $FICHERO_DESCARGA
	rm $MOTION
	exit 0

}

inicio
finishcheck
