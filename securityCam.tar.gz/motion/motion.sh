#!/bin/bash

REP=mplayer

function Menu {
	echo "-------------Menu---------------"
    echo "1. Iniciar grabación"
    echo "2. Ver grabacion"
    echo "3. Salir"
	echo "--------------------------------"
}

function Opcion {
	 case $opcion in
  	1) 
		motion -c ~/.motion/motion.conf 
    	echo "CTRL+C parar grabación"
		;;	

  	2)	
		clear
		echo "--------------grabaciones---------------"
		cd ~/cam/ 
		ls
		echo "-----------------------------------------"
		echo "introduce nombre archivo"
		read NOM
		$REP $NOM
		;;
  	
	3) exit 0
		;;

  	*) 
		echo "$opc es una opcion invalida.";
  	 	echo "Presiona una tecla para continuar...";
  	 	read foo;;
 	esac
}
clear
whoami
while [ "$opcion" != 3 ]
do
	Menu
	echo "Seleccione una opcion [1 - 3]" 
	read opcion
 	Opcion
done 

