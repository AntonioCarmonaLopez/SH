<?php

//creo cabeceras desde PHP para decir que devuelvo un XML
header("Content-type: text/xml");

//comienzo a escribir el c�digo del RSS
echo "<?xml version=\"1.0\""." encoding=\"ISO-8859-1\"?>";

//conecto con la base de datos
$Servidor = "localhost";
$usuario = "****";
$clave = "****";
$bbdd = "****";
$connectid = mysql_connect($Servidor, $usuario, $clave);
mysql_select_db($bbdd);

//sentencias SQL 
$ssql = "select * from ****";
$result = mysql_query($ssql);

$ssql1 = "select * from ****";
$result1 = mysql_query($ssql1);

$ssql2 = "select * from ****";
$result2 = mysql_query($ssql2);

$ssql3 = "select * from ****";
$result3 = mysql_query($ssql3);

$ssql4 = "select * from ****";
$result4 = mysql_query($ssql4);

//Cabeceras del RSS
echo '<rss version="2.0">';

//Datos generales del Canal. Ed�talos conforme a tus necesidades
echo "<channel>\n";

echo "<title>Antonio Carmona-L�pez</title>";

echo "<link>http://www.antoniocarmona.biz</link>";

echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions.</description>";

echo "<language>es-es</language>";

echo "<lastBuildDate>$FECHA</lastBuildDate>\n";

echo "<ttl>2</ttl>";

//crear un item para cada entrada
$FECHA="Thu, 23 Jul 2015 10:00:36 +0200";
$aleatorio=rand();
while ($registro = mysql_fetch_array($result)){

	$nombre=clrAll($registro["nombre"]);			
	$enlace=clrAll($registro["enlace"]);
	$enlace1=$enlace;
	$enlace1 .=$aleatorio;
	$enlace1 .=1;

	echo "<item>\n";
	
	echo "<title>$nombre</title>\n";
	
	echo "<link>http://antoniocarmona.biz/demos/firefox.php</link>\n";
	
	echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions</description>\n";
	
	echo "<pubDate>$FECHA</pubDate>\n";
	
	echo "<guid>$enlace1</guid>\n";
	
	echo "</item>\n";
	
}

while ($registro = mysql_fetch_array($result1)){
	//elimino caracteres extra�os en campos susceptibles de tenerlos
	$nombre=clrAll($registro["nombre"]);			
	$enlace=clrAll($registro["enlace"]);
	$enlace1=$enlace;
	$enlace1 .=$aleatorio;
	$enlace1 .="??";

	echo "<item>\n";
	
	echo "<title>$nombre</title>\n";
	
	echo "<link>http://antoniocarmona.biz/demos/html.php</link>\n";
	
	echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions</description>\n";

	echo "<pubDate>$FECHA</pubDate>\n";

	echo "<guid>$enlace1</guid>\n";

	echo "</item>\n";

}

while ($registro = mysql_fetch_array($result2)){

	$nombre=clrAll($registro["nombre"]);			
	$enlace=clrAll($registro["enlace"]);
	$enlace1=$enlace;
	$enlace1 .=$aleatorio;

	echo "<item>\n";
	
	echo "<title>$nombre</title>\n";
	
	echo "<link>http://antoniocarmona.biz/demos/php.php</link>\n";

	echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions</description>\n";
	
	echo "<pubDate>$FECHA</pubDate>\n";
	
	echo "<guid>$enlace1</guid>\n";

	echo "</item>\n";

}

while ($registro = mysql_fetch_array($result3)){

	$nombre=clrAll($registro["nombre"]);			
	$enlace=clrAll($registro["enlace"]);
	$enlace1=$aleatorio;

	echo "<item>\n";

	echo "<title>$nombre</title>\n";

	echo "<link>http://antoniocarmona.biz/demos/sh.php</link>\n";

	echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions</description>\n";
	
	echo "<pubDate>$FECHA</pubDate>\n";

	echo "<guid>$enlace1</guid>\n";

	echo "</item>\n";

}

while ($registro = mysql_fetch_array($result4)){

	$nombre=clrAll($registro["nombre"]);			
	$enlace=clrAll($registro["enlace"]);
	$enlace1=$enlace;
	$enlace1 .=$aleatorio;

	echo "<item>\n";

	echo "<title>$nombre</title>\n";

	echo "<link>http://antoniocarmona.biz/demos/vb.php</link>\n";
	
	echo "<description>Web personal de Antonio Carmona-L�pez en donde se pone a disposici�n de todos los usuarios registrados una serie de peque�as soluciones en diferentes lenguajes, tales como PHP, HTML, SH o VB, libres de ser modificadas/mejoradas, para adaptarlas a las necesidades personales.-Antonio Carmona's personal webpage where you can find diferents web solutions</description>\n";
	
	echo "<pubDate>$FECHA</pubDate>\n";

	echo "<guid>$enlace1</guid>\n";

	echo "</item>\n";

}
//cerrar las etiquetas del XML
echo "</channel>";

echo "</rss>";

?>


