<?php


//crear cabeceras desde PHP para decir que devuelvo un XML
header("Content-type: text/xml");

//comienzo a escribir el c�digo del RSS
echo "<?xml version=\"1.0\""." encoding=\"ISO-8859-1\"?>";

//conecto con la base de datos
$Servidor = "****";
$usuario = "****";
$clave = "****";
$bbdd = "****";
$connectid = mysql_connect($Servidor, $usuario, $clave);
mysql_select_db($bbdd);


$ssql = "select * from wp_posts where post_type='post'";
$result = mysql_query($ssql);

$FECHA="Thu, 30 Jul 2015 10:05:00 GMT";
//Cabeceras del RSS
echo '<rss version="2.0">';

echo "<channel>\n";
echo "<title>TIPS en GNU/LINUX</title>\n";
echo "<link>http://www.blog.antoniocarmona.biz</link>\n";
echo "<description>Blog personal de Antonio Carmona L�pez con tem�tica que gira en torno al software libre.</description>\n";
echo "<language>es-es</language>";
echo "<lastBuildDate>$FECHA</lastBuildDate>\n";
echo "<ttl>2</ttl>";


while ($registro = @mysql_fetch_array($result)){
	$aleatorio=rand(1,1000);
	$aleatorio1=rand(10001,20000);

	$titulo=clrAll($registro["post_title"]);			
	$enlace=clrAll($registro["guid"]);

	echo "<item>\n";
	echo "<title>$titulo</title>\n";
	echo "<link>$enlace</link>\n";
	echo "<pubdate>$FECHA</pubdate>\n";
	echo "<author>Antonio Carmona-L�pez</author>\n";
	echo "<guid>$FECHA-$aleatorio-$aleatorio1</guid>";
	echo "</item>\n";
}

//cierrar las etiquetas del XML
echo "</channel>";
echo "</rss>";

?>
