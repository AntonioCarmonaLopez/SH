#!/bin/bash

function Adominio {
	LOCAL="http://127.0.0.1/"
	DOMINIO="http://antoniocarmona.biz/blog"

	echo $DOMINIO
	sed -i "s|$LOCAL|$DOMINIO|g" feed.xml
	
	if [ $? = 0 ] ; then
		echo "Dominios actualizados"
	else
		echo "Dominios no actualizados"
	fi
}

function Afecha {
	export LC_TIME="en_US.utf8"

	DIA=`date +%a`
	DIAMES=`date +%d`
	NOMNES=`date +%b`
	ANO=`date +%Y`
	HORA="09:00:00 GMT"

	FORMATEADA="$DIA, $DIAMES $NOMNES $ANO $HORA"

	cadena="<pubdate>"$FORMATEADA"</pubdate>"
		
	echo "nueva" $cadena

	salida=`cat feed.xml | grep -A 1 "</description>"| tail -1
`

	echo "antigua" $salida

	sed  -i "s|$salida|$cadena|g" feed.xml
	
	if [ $? = 0 ] ; then
		echo "Fechas actualizadas"
	else
		echo "Fechas no actualizadas"
	fi
	export LC_TIME="es_ES.utf8"
}

Adominio
Afecha
